const mongoose = require('mongoose');

// Define the travel trip schema with strict validation and optimization
const tripSchema = new mongoose.Schema(
  {
    code: {
      type: String,
      required: [true, 'Trip code is required'],
      unique: true,
      trim: true,
      index: true
    },
    name: {
      type: String,
      required: [true, 'Trip name is required'],
      trim: true
    },
    length: {
      type: String,
      required: [true, 'Trip length is required'],
      trim: true
    },
    start: {
      type: Date,
      required: [true, 'Trip start date is required']
    },
    resort: {
      type: String,
      required: [true, 'Resort name is required'],
      trim: true
    },
    perPerson: {
      type: String,
      required: [true, 'Per person cost is required'],
      trim: true
    },
    image: {
      type: String,
      required: [true, 'Image path is required'],
      trim: true
    },
    description: {
      type: String,
      required: [true, 'Trip description is required'],
      trim: true
    }
  },
  {
    timestamps: true
  }
);

// Compound index to optimize query performance for resort and date searches
tripSchema.index({ resort: 1, start: 1 });

module.exports = mongoose.model('trips', tripSchema);